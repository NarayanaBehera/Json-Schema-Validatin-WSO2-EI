Running WSO2 Carbon Server as a Windows Service
------------------------------------------------

1. Download the latest stable version of YAJSW from the project home page. (http://yajsw.sourceforge.net/)
2. Unzip the YAJSW archive and place the provided wrappe.conf file (this directory) inside <YAJSW.Home.Dir>/conf.
3. Set JAVA_HOME and CARBON_HOME system properties
4. Start the product as a windows service. (batch scripts are found under <YAJSW.Home.Dir>/bat)

For more detailed info please refer to Carbon wiki documentation (http://docs.wso2.org/wiki/dashboard.action) and YAJSW project documentation.
